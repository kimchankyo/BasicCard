# BasicPlayingCard

Playing card games is simple. So should developing them.